# TODO

Esta es una lista de TODO sin order de prioridad específico.

## Por hacer

- Traducción al Español
- Control de acceso específica a nivel de usuario
- Integración con Odoo para la gestión
- UI? (web?)
- Otros? (Utiliza los [issues](https://github.com/stdevPavelmc/mailad/issues) para esto)

## Completados

- Segregación de usuario por grupos de Active Directory (local/nacional/acceso internacional) [Julio/2020]
- Estadísticas diarias con pflogsumm [Agosto/2020]
- Filtrado de contenidos más allá de lo básico (mime y extensiones) [Septiembre/2020]
- Filtrado de spam con SpamAssasin [Septiembre/2020]
- Scaneo anti virus con ClamAV [Septiembre/2020]
