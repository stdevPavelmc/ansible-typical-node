# TODO

This page is also available in the following languages: [ [Español](i18n/TODO.es.md) 🇪🇸 🇨🇺]

This is a To Do list with no particular order

## New Features/Wish/To Do items

- Spanish translation
- Specific access control at each user level
- Odoo integration for management
- UI? (web?)
- Any other (Use the Issues tab for that)

## Already Done Items

- Users access segregation via AD groups (local/national/international access) [July/2020]
- Daily statistics via pflogsumm [August/2020]
- Content filtering (mime & extensions) beyond the basics [September/2020]
- Spam filtering via SpamAssasin [September/2020]
- Anti Virus scan using ClamAV [September/2020]
