---
name: Translation request
about: Request a translation
title: "[TRANSLATION] "
labels: translation
assignees: stdevPavelmc

---

**List the files you need to be translated and the language you need**
ES: /i18n/README.es.md (update after issue ...)
